DINHEIRO EM DIA - Estrutura para hospedagem

Arquivos:
- index.html
- css/style.css
- js/firebase-config.js
- js/app.js

Como hospedar:
1. Envie todos os arquivos mantendo as pastas css e js.
2. Abra o index.html no navegador ou publique no GitHub Pages/Firebase Hosting.
3. Se trocar de projeto Firebase, altere somente js/firebase-config.js.

Observação:
O código foi separado sem alterar a lógica principal do sistema.
